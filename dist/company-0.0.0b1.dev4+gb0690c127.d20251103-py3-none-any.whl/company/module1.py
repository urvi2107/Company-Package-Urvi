

def print_name(name):
    print("Hello", name,"!")

if __name__ == "__main__":
    print_name("Urvi")
