from .base_company import Company
from .medical.medical import MedicalCompany


from .version import __version__  
print(f"Company package version: {__version__}")